#!/usr/bin/perl

use strict;
use warnings;
print "+-------------------------------------------------------\n";
print "|               Perl Example\n";
print "+-------------------------------------------------------\n";

my $STR="We're just two lost souls swimming in a fish bowl year after year";
my @ARRAY=split " ",$STR;
print "---------------------------------------------------\n";
print "An example of using join:".join ("\n",@ARRAY);


print "---------------------------------------------------\n";
my @GRP_ARRAY=grep "o",@ARRAY;
print "An example of using grep".join ("\n",@GRP_ARRAY);



print "---------------------------------------------------\n";
print "An example of using pop:\nbefore:".join (",",@ARRAY)."\n";
my $VAR=pop @ARRAY;
print "after :".join (",",@ARRAY)."\n";

print "var='$VAR'\n";


