#!/usr/bin/perl

use strict;
use warnings;
print "+-------------------------------------------------------\n";
print "|               Perl Example\n";
print "+-------------------------------------------------------\n";

my $ME='Sagiv Barhoom';
my $YOU='TELUX';


if ($ME=~/Sagiv/){
    print "'$ME' matches /Sagiv/\n";
}
else{
    print "'$ME' does not  matches /Sagiv/\n";
}

if ($ME=~/SAGIV/){
    print "'$ME' matches /SAGIV/\n";
}
else{
    print "'$ME' does not matches /SAGIV/\n";
}

if ($ME=~/SAGIV/i){
    print "'$ME' matches  /SAGIV/i\n";
}
else{
    print "'$ME' does not matches  /SAGIV/i\n";
}

if ($ME=~/^Barhoom/i){
    print "'$ME' matches  /^Barhoom/i\n";
}
else{
    print "'$ME' does not matches  /^Barhoom/i\n";
}

print "Type a cell phone number in the format '05x-xxxxxxx': ";
while (<>) {
    chomp;
    if (/^05[0247]-\d{7}$/){
        print "'$_' is valid phone number";
        last;
    }
    else{
        print "'$_' is not a valid phone number\n";
        print "Type a cell phone number in the format '05x-xxxxxxx': ";
    }
}



