#!/usr/bin/perl

use strict;
use warnings;
print "+-------------------------------------------------------\n";
print "|               Perl Example\n";
print "+-------------------------------------------------------\n";


my @FIRST_ARR=( 'black', 'grey','silver' );
my @SECOND_ARR;
$SECOND_ARR[1]='black';
$SECOND_ARR[2]='grey';
$SECOND_ARR[3]='silver';


print "=================FIRST_ARR====================\n";
print '$FIRST_ARR[1] is: '.$FIRST_ARR[1]."\n";

print "=================SECOND_ARR====================\n";
print '$SECOND_ARR[1] is: '.$SECOND_ARR[1]."\n"; 
