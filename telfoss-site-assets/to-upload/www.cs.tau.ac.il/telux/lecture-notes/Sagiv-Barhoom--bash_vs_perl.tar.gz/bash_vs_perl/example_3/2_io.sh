#!/bin/bash



echo  "+-------------------------------------------------------"
echo  "|               Bash Example"
echo  "+-------------------------------------------------------"

echo -ne  "This is output without new line, do you understand (Y/n)? "
read INPUT

echo  "1. INPUT=$INPUT"
echo  "2. INPUT='$INPUT'";
echo  '3. INPUT=$INPUT';

