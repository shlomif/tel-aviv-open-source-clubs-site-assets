#!/usr/bin/perl

use strict;
use warnings;
print "+-------------------------------------------------------\n";
print "|               Perl Example\n";
print "+-------------------------------------------------------\n";

my $FIRST=1;
my $LAST=5;

print "========= while loop 1 ==========\n";
my $i=$FIRST;
while ( $i <= $LAST )
{
    print "$i\n";
    $i++;
}


print "========= while loop 2 (using last) ==========\n";
$i=$FIRST;
while ( 1 eq 1 )
{
    print "$i\n";
    $i++;
    ( $i le $LAST ) or last ;
}
