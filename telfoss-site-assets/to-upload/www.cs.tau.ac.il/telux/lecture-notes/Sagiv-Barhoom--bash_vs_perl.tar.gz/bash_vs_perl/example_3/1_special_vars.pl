#!/usr/bin/perl
use strict;
use warnings;

print "+-------------------------------------------------------\n";
print "|               Perl Example\n";
print "+-------------------------------------------------------\n";

print "$ARGV[0] is the first  positional parameter, \$ARGV[0].\n";
print "$ARGV[1] is the second positional parameter, \$ARGV[1].\n";
print "$ARGV[2] is the third  positional parameter, \$ARGV[2].\n\n";

print "The total number of positional parameters is ".scalar @ARGV."\n";

print "program name is $0"
open my $fh , "<", "file_that_does_not_exists" or die "ERROR: '$!'";
close($fh);
