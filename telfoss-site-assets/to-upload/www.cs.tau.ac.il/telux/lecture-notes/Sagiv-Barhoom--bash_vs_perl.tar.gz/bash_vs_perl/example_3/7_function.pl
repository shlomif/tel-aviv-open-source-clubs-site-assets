sub  log_it{
	my	($LOG_NAME,$SEVERITY,$MSG)	= @_;
    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
    my $DATE= sprintf("%02d-%02d-%04d %02d:%02d:%02d", 
                        $year,$mon,$mday,$hour,$min,$sec);

    open $LOG,'>>',$LOG_NAME or die "could not open log file for $MSG' due to:$!";
    printf   $LOG "%-20s [%5s] %s",$DATE,$SEVERITY,$MSG;   
    close $LOG;
    
    return ;
}	# ----------  end of subroutine   ----------
