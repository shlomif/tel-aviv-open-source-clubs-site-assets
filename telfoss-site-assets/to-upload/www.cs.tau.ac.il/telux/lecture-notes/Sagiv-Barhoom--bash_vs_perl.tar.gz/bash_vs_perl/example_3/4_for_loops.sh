#!/bin/bash



echo  "+-------------------------------------------------------"
echo  "|               Bash Example"
echo  "+-------------------------------------------------------";


echo  "======== for loop 1 =========="
for i in 1 2 3 4 5
do
    echo  $i
done


echo  "======== for loop 2 =========="
for i in `seq 1 5` 
do
    echo  $i
done


echo  "======== for loop 3 =========="
for i in `ls`
do
    echo  $i
done
