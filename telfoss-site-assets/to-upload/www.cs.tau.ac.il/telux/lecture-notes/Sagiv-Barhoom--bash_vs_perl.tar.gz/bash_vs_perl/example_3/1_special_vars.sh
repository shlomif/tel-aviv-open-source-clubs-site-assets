#!/bin/bash



echo  "+-------------------------------------------------------"
echo  "|               Bash Example"
echo  "+-------------------------------------------------------";


echo  "$1 is the first  positional parameter, \$1."
echo  "$2 is the second positional parameter, \$2."
echo  "$3 is the third  positional parameter, \$3."
echo 
echo  "The total number of positional parameters is $#."

echo "program name is: $0"

ech mple_4 "========== other examples =========="

ls -l '/etc/passwd'
echo  $? # exit code is ok

ls -l './file_that_does_not_exists'
echo  $? # exit code is not ok

