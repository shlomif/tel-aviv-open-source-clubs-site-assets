#!/usr/bin/perl

use strict;
use warnings;
print "+-------------------------------------------------------\n";
print "|               Perl Example\n";
print "+-------------------------------------------------------\n";
my $i;

print "======== for loop 1 ==========\n";
for $i (1,2,3,4,5)
{
    print "$i\n";
}


print "======== for loop 2 ==========\n";
for $i (1..5)
{
    print "$i\n";
}


print "======== for loop 3 ==========\n";
for $i (glob "*")
{
    print "$i\n";
}

