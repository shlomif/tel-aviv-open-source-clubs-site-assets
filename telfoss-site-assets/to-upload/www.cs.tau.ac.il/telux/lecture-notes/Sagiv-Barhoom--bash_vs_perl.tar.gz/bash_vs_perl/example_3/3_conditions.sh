#!/bin/bash



echo  "+-------------------------------------------------------"
echo  "|               Bash Example"
echo  "+-------------------------------------------------------";

ME='Sagiv Barhoom'
YOU='TELUX'

echo  "========  testing equal ========"
if [ "$ME" == "$ME" ]
then
    echo  "'$ME' and '$ME' are the same."
fi

if [ "$ME" != "$YOU" ]
then
    echo  "'$ME' and '$YOU' are not the same."
fi

echo  "======== if else example ========"
if [ "$ME" == "$YOU" ]
then
    echo  "'$ME' and '$YOU' are the same."
else
    echo  "'$ME' and '$YOU' are not the same."
fi



