#!/bin/bash



echo  "+-------------------------------------------------------"
echo  "|               Bash Example"
echo  "+-------------------------------------------------------";


FIRST_ARR=( black grey silver )
SECOND_ARR[1]=black
SECOND_ARR[2]=grey
SECOND_ARR[3]=silver


echo "=================FIRST_ARR===================="
echo '$FIRST_ARR[1] is:' ${FIRST_ARR[1]}

echo "=================SECOND_ARR===================="
echo '$SECOND_ARR[1] is:' ${SECOND_ARR[1]}
