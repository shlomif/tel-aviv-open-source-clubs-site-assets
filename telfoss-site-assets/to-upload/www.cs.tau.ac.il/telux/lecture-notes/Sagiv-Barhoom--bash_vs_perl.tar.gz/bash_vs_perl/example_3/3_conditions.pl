#!/usr/bin/perl

use strict;
use warnings;
print "+-------------------------------------------------------\n";
print "|               Perl Example\n";
print "+-------------------------------------------------------\n";

my $ME='Sagiv Barhoom';
my $YOU='TELUX';

print "========  testing equal ========\n";
if ( "$ME" eq "$ME" )
{
    print  "'$ME' and '$ME' are the same.\n";
}

if ( "$ME" ne "$YOU" )
{
    print "'$ME' and '$YOU' are not the same.\n";
}

print "======== if else example ========\n";
if ( "$ME" eq "$YOU" )
{
    print "'$ME' and '$YOU' are the same.\n";
}
else
{
    print "'$ME' and '$YOU' are not the same.\n";
}
