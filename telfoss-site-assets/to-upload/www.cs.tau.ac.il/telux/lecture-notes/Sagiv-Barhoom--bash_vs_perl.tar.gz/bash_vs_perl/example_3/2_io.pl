#!/usr/bin/perl

use strict;
use warnings;
print "+-------------------------------------------------------\n";
print "|               Perl Example\n";
print "+-------------------------------------------------------\n";

print "This is output without new line, do you understand (Y/n)? ";
my $INPUT=<>;
chomp $INPUT;
print "1. INPUT=$INPUT\n";
print "2. INPUT='$INPUT'\n";
print '3. INPUT=$INPUT'."\n";

