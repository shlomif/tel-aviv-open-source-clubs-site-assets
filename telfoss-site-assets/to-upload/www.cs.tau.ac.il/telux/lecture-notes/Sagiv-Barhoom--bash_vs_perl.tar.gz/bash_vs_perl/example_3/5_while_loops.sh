#!/bin/bash



echo  "+-------------------------------------------------------"
echo  "|               Bash Example"
echo  "+-------------------------------------------------------";

FIRST=1
LAST=5

echo  "========= while loop 1 =========="
declare -i i=$FIRST
while [ $i -le $LAST ] 
do
    echo  $i
    i=$i+1
done

echo  "========= while loop 2 (using break) =========="
i=$FIRST
while [ 1 -eq 1 ]
do
    echo  $i
    i=$i+1
    [ $i -le $LAST ] || break 

done
