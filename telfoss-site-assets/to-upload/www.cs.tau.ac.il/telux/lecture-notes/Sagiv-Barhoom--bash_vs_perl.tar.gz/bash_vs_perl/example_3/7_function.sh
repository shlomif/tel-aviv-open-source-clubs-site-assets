function log_it ()
{
    DATE=`date   +"%F %H:%M:%S"`
    LOG_NAME=$1
    SEVERITY=$2
    MSG=$3
    
    printf "%-20s [%5s] %s\n" "$DATE" "$SEVERITY" "$MSG" >> $LOG_NAME  

	return
}    # ----------  end of function log_it  ----------
