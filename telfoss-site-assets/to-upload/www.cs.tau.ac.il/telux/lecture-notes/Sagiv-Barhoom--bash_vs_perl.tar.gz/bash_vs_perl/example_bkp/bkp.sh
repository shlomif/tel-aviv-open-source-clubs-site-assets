#!/bin/bash



echo  "+-------------------------------------------------------"
echo  "|               Bash Example"
echo  "+-------------------------------------------------------"
root_dir='/home/sagivba/Documents/bash_vs_perl'
dirs2bkp=(
"example_1"
"dir_that_does_not_exists"
"example_2"
"example_3"
"example_4"
)

bkp_file_name='/tmp/bkp.bash.gk.zip'
log_file_name='/tmp/bash_bkp.log'
bkp_cmd="/usr/bin/zip -r -v $bkp_file_name";


function log_it ()
{
    DATE=`date   +"%F %H:%m:%S"`
    LOG_NAME=$1
    SEVERITY=$2
    MSG=$3
    
    printf "%-20s [%4s] %s\n" "$DATE" "$SEVERITY" "$MSG" >> $LOG_NAME  

	return
}    # ----------  end of function log_it  ----------

for dir in  ${dirs2bkp[@]}
do
    dir="$root_dir/$dir";
    if [ -d $dir ]
    then
        log_it $log_file_name 'INFO' "found '$dir' - so I will add it to my list" ;
        bkp_cmd="$bkp_cmd $dir"; 
    
    else
        log_it $log_file_name 'WARN' "'$dir' does not exists" ;
    fi

done               

log_it $log_file_name 'INFO' "$bkp_cmd";
$bkp_cmd
if [ $? -ne 0 ]
then
    log_it $log_file_name 'WARN' 'could not backup';
fi

exit 0;

