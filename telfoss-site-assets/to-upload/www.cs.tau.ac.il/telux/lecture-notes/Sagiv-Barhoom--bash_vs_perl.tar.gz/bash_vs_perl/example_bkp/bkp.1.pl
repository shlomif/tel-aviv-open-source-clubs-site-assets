#!/usr/bin/perl

use strict;
use warnings;
print "+-------------------------------------------------------\n";
print "|               Perl Example for backup script\n";
print "+-------------------------------------------------------\n";

my $root_dir='';
my @dirs2bkp=(
"etc"
);

my $bkp_file_name='/tmp/bkp.perl.gk.zip';
my $log_file_name='/tmp/perl_bkp.log';
my @bkp_cmd=('/usr/bin/zip','-r','-v',$bkp_file_name);


foreach my $dir ( @dirs2bkp ) {
    $dir="$root_dir/$dir";
    if ( -d $dir ){
        log_it ($log_file_name,'INFO',"found '$dir' - so I will add it to my list" );
        push @bkp_cmd,$dir; 
    }
    else{
        log_it ($log_file_name,'WARN',"'$dir' does not exists" );
    }

}               # -----  end foreach  -----

log_it($log_file_name,'INFO',join (" ",@bkp_cmd));
if (system(@bkp_cmd)!=0){
    log_it ($log_file_name,'WARN',"could not backup");
}

exit 0;


sub  log_it{
    my      ($LOG_NAME,$SEVERITY,$MSG)      = @_;
    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
    my $DATE= sprintf("%02d-%02d-%04d %02d:%02d:%02d",
                        $year,$mon,$mday,$hour,$min,$sec);

    open my $LOG,'>>',$LOG_NAME or die "could not open log file for $MSG' due to:$!";
    printf   $LOG "%-20s [%4s] %s\n",$DATE,$SEVERITY,$MSG;
    close $LOG;

    return ;
}       # ----------  end of subroutine   ----------

