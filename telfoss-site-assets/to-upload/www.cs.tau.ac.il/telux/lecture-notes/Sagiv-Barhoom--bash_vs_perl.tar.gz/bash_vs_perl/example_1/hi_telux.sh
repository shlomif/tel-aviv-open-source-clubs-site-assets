#!/bin/bash

echo "Hi telux :-)"
